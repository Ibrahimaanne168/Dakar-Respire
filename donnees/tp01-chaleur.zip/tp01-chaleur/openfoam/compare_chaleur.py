"""
TP 1 -- Comparaison OpenFOAM / schéma explicite Python / solution exacte
=========================================================================

Solution exacte (série de Fourier) du problème T = 1 au départ, T = 0 en x = ±1 :

    T(x, t) = Σ_k  4 (-1)^k / ((2k+1) π)  cos((2k+1) π x / 2)  exp(-((2k+1) π / 2)² t)

Organisation du fichier
-----------------------
    BLOC 1  solution exacte
    BLOC 2  lecture du champ T d'OpenFOAM (centres des mailles)
    BLOC 3  schéma explicite Python (le même que chaleur.py)
    BLOC 4  écarts aux instants 0,1 ... 0,5 et figure chaleur_openfoam.png

Usage : python3 compare_chaleur.py   (lancé par Allrun, dans le dossier du cas)
"""
import re

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

INSTANTS = (0.1, 0.2, 0.3, 0.4, 0.5)     # dossiers de temps écrits par OpenFOAM


# =============================================================================
# BLOC 1 -- SOLUTION EXACTE
# =============================================================================
def exacte(x, t, K=200):
    """Somme des K premiers termes de la série (largement convergée pour t ≥ 0,1)."""
    T = np.zeros_like(x)
    for k in range(K):
        a = (2 * k + 1) * np.pi / 2
        T += 4 / ((2 * k + 1) * np.pi) * (-1)**k * np.cos(a * x) * np.exp(-a**2 * t)
    return T


# =============================================================================
# BLOC 2 -- LECTURE DU CHAMP OPENFOAM
# =============================================================================
def lire(t):
    """Valeurs de T aux centres des mailles, dans le dossier de temps t."""
    s = open(f"{t:g}/T").read()
    m = re.search(r"internalField\s+nonuniform\s+List<scalar>\s*\d+\s*\((.*?)\)", s, re.S)
    return np.array(m.group(1).split(), float)


# =============================================================================
# BLOC 3 -- SCHÉMA EXPLICITE PYTHON (même calcul que chaleur.py)
# =============================================================================
def explicite(n=100, dt=1e-5, tmax=0.5, sorties=INSTANTS):
    """Renvoie les nœuds x et un dictionnaire {instant : profil T}."""
    x = np.linspace(-1, 1, n + 1)
    T = np.ones(n + 1)
    T[0] = T[-1] = 0
    r = dt / (x[1] - x[0])**2                 # nombre de Fourier du maillage
    res = {}
    it = 0
    for k in range(int(round(tmax / dt))):
        T[1:-1] = T[1:-1] + r * (T[2:] - 2 * T[1:-1] + T[:-2])
        it += 1
        for ts in sorties:                     # instant demandé atteint ?
            if abs(it * dt - ts) < dt / 2:
                res[ts] = T.copy()
    return x, res


# =============================================================================
# BLOC 4 -- ÉCARTS ET FIGURE
# =============================================================================
if __name__ == "__main__":
    xc = np.linspace(-1, 1, 101)
    xc = 0.5 * (xc[1:] + xc[:-1])             # centres des 100 mailles OpenFOAM
    xe, Te = explicite()
    fig, ax = plt.subplots(figsize=(7, 4))
    for t in INSTANTS:
        Tof = lire(t)
        ex = exacte(xc, t)
        print(f"t = {t} : max T OpenFOAM {Tof.max():.5f}, exacte {ex.max():.5f}, "
              f"écart OpenFOAM {np.abs(Tof-ex).max():.1e}, explicite Python {np.abs(Te[t]-exacte(xe,t)).max():.1e}")
        ax.plot(xc, Tof, "o", ms=2)
        ax.plot(xc, ex, "k-", lw=.8)
    ax.set_xlabel("x"); ax.set_ylabel("T"); ax.set_title("OpenFOAM (points) et solution exacte (traits)")
    ax.grid(alpha=.3); fig.tight_layout(); fig.savefig("chaleur_openfoam.png", dpi=120)
