"""
TP 1 -- Équation de la chaleur 1D, schéma explicite (squelette à compléter)
=========================================================================

Problème
--------
    ∂T/∂t = ∂²T/∂x² ,   -L < x < L ,   T(-L, t) = T(L, t) = 0 ,   T(x, 0) = 1 .

Une barre initialement à T = 1 dont les deux bouts sont brusquement mis à 0.

Méthode (chapitre 3 du cours, d'après P.-Y. Lagrée)
---------------------------------------------------
Schéma explicite : Euler avant en temps, différence centrée en espace.

    T_i^{n+1} = T_i^n + r (T_{i+1}^n − 2 T_i^n + T_{i-1}^n) ,   r = Δt / Δx² .

Stable si r ≤ 1/2, soit Δt ≤ Δx²/2.

Notations
---------
    Nmax : nombre de segments (Nmax + 1 nœuds, x_0 = -L, x_Nmax = L)
    T    : température au temps courant, Tn : température au pas suivant

Organisation du fichier
-----------------------
    BLOC 0  paramètres physiques et numériques
    BLOC 1  vérification de la condition de stabilité
    BLOC 2  maillage et condition initiale
    BLOC 3  boucle en temps (schéma explicite)
    BLOC 4  sauvegarde des instantanés (resultat.dat, même format que chaleur.c)
    BLOC 5  tracé (équivalent de plot.gp)

À faire : compléter uniquement les lignes marquées TODO (BLOCS 1 à 3).

Usage
-----
    python chaleur_squelette.py          (dépendances : numpy, matplotlib)
Équivalent en C : chaleur.c (gcc chaleur.c -o chaleur -lm), tracé avec plot.gp.

Arrêt net : tant qu'une ligne TODO n'est pas complétée, le programme s'arrête avec le
message « ligne à compléter » et le numéro du bloc. Une fois la ligne complétée, supprimer
l'appel a_completer(...) placé juste à côté.
"""
import numpy as np
import matplotlib.pyplot as plt


def a_completer(message):
    """Arrête le programme avec un message clair tant qu'une ligne TODO n'est pas complétée."""
    raise NotImplementedError(f"ligne à compléter -- {message}")


# =============================================================================
# BLOC 0 -- PARAMÈTRES PHYSIQUES ET NUMÉRIQUES
# =============================================================================
Nmax = 100                     # nombre de segments
L = 1.0                        # demi-largeur du domaine [-L, L]
dx = 2.0 * L / Nmax            # pas d'espace
dt = 0.00001                   # pas de temps
tmax = 0.5                     # temps final simulé
nsteps = int(round(tmax / dt)) # nombre de pas de temps (arrondi : 0.5/1e-5 vaut 49999,99...)
save_every = 500               # un instantané sauvegardé tous les 500 pas


# =============================================================================
# BLOC 1 -- CONDITION DE STABILITÉ DU SCHÉMA EXPLICITE
# =============================================================================
def verifier_stabilite(dx, dt):
    """Affiche Δx, Δt et la limite Δx²/2 ; avertit si le schéma va diverger."""
    print("Resolution equation de la chaleur (Lagree, version Python)")
    # TODO 1 : calculer dt_limite = dx^2 / 2, l'afficher, et afficher un
    #          avertissement si dt >= dt_limite
    a_completer("BLOC 1")   # à supprimer une fois la ligne TODO complétée


# =============================================================================
# BLOC 2 -- MAILLAGE ET CONDITION INITIALE
# =============================================================================
def initialiser(Nmax, L):
    """Nœuds x_i et créneau initial T = 1, avec T = 0 aux deux bords."""
    x = np.linspace(-L, L, Nmax + 1)
    T = np.ones(Nmax + 1)
    # TODO 2 : imposer les conditions aux limites sur T (bords à 0)
    a_completer("BLOC 2")   # à supprimer une fois la ligne TODO complétée
    return x, T


# =============================================================================
# BLOC 3 -- BOUCLE EN TEMPS : SCHÉMA EXPLICITE
# =============================================================================
def avancer(T, dt, dx, nsteps, save_every):
    """Fait nsteps pas de temps. Renvoie la liste des instantanés (t, T)."""
    snapshots = []             # liste de tuples (t, copie de T)
    t = 0.0
    for it in range(nsteps + 1):
        if it % save_every == 0:
            snapshots.append((t, T.copy()))

        # nœuds intérieurs : T_i + r (T_{i+1} - 2 T_i + T_{i-1}), r = dt/dx²
        Tn = T.copy()
        # TODO 3 : calculer Tn[1:-1] avec le schéma explicite
        #   Tn[i] = T[i] + (dt/dx**2) * (T[i+1] - 2*T[i] + T[i-1])
        #   Astuce : découpage numpy T[1:-1], T[2:], T[:-2]
        a_completer("BLOC 3")   # à supprimer une fois la ligne TODO complétée

        # TODO 4 : réimposer les conditions aux limites sur Tn
        a_completer("BLOC 3")   # à supprimer une fois la ligne TODO complétée

        T = Tn
        t += dt
    return snapshots


# =============================================================================
# BLOC 4 -- SAUVEGARDE (même format que resultat.dat du programme C)
# =============================================================================
def sauvegarder(x, snapshots, nom="resultat.dat"):
    """Un bloc par instantané, séparé par deux lignes vides (lisible par gnuplot,
    option « index »)."""
    with open(nom, "w") as f:
        for t_snap, T_snap in snapshots:
            f.write(f"# t={t_snap:.6f}\n")
            for xi, Ti in zip(x, T_snap):
                f.write(f"{xi:.6f} {Ti:.6f}\n")
            f.write("\n\n")


# =============================================================================
# BLOC 5 -- TRACÉ (équivalent de plot.gp)
# =============================================================================
def tracer(x, snapshots, nom="chaleur_python.png"):
    """Un profil sur dix, comme plot.gp."""
    plt.figure(figsize=(9, 6))
    for i in range(0, len(snapshots), 10):
        t_snap, T_snap = snapshots[i]
        plt.plot(x, T_snap, linewidth=2, label=f"t={t_snap:.3f}")
    plt.xlabel("x")
    plt.ylabel("T(x,t)")
    plt.title("Diffusion de la chaleur - equation dT/dt = d2T/dx2")
    plt.xlim(-1, 1)
    plt.ylim(0, 1.05)
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5))
    plt.tight_layout()
    plt.savefig(nom, dpi=150)
    plt.show()


# =============================================================================
# PROGRAMME PRINCIPAL
# =============================================================================
if __name__ == "__main__":
    verifier_stabilite(dx, dt)
    x, T = initialiser(Nmax, L)
    snapshots = avancer(T, dt, dx, nsteps, save_every)
    print(f"Termine. {len(snapshots)} instantanes calcules.")
    sauvegarder(x, snapshots)
    tracer(x, snapshots)
